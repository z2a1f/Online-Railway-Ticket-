from django.apps import AppConfig


class RailwayConfig(AppConfig):
    name = 'railway'
